### Hexlet tests and linter status:
[![Actions Status](https://github.com/AyratKhalikov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AyratKhalikov/python-project-49/actions)

#asciinema_link_step5 https://asciinema.org/connect/bb48b99b-3a43-4854-aeb2-a0930ed50fad
#asciinema_link_step6 https://asciinema.org/a/xWgPeGh7OAVrDuFVwZSw5tPvb
